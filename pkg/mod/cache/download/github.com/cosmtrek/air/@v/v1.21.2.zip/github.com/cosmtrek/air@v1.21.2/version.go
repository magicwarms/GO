package main

const (
	airVersion = "1.12.1"
	goVersion  = "1.14.0"
)
